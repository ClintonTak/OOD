package hw5;
import javafx.scene.image.*;
public interface FishType {
    Image rightImage();
    Image leftImage();
}
