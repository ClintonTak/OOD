package hw5;

public abstract class FishFactory {
    abstract Fish create();
}
