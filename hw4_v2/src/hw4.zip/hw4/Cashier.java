package hw4;

public interface Cashier {
    public void elapseOneSecond(Customer customer);
    public String cashierType();
}
