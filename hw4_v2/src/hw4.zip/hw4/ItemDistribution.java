package hw4;

public interface ItemDistribution {

    public int generate();
}
